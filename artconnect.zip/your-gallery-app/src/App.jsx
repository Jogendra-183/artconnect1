import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ArtistDashboard from './pages/ArtistDashboard';
import VisitorDashboard from './pages/VisitorDashboard';
import CuratorDashboard from './pages/CuratorDashboard';
import LoginPage from './pages/LoginPage'; // ✨ IMPORT: Add the new login page

function App() {
  return (
    <div className="app-container">
      <Navbar />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/artist-dashboard" element={<ArtistDashboard />} />
          <Route path="/visitor-dashboard" element={<VisitorDashboard />} />
          <Route path="/curator-dashboard" element={<CuratorDashboard />} />
          <Route path="/login" element={<LoginPage />} /> {/* ✨ ADD: New route for login */}
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;