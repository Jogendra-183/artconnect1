import React, { useState } from 'react';
import placeholderImg from '../assets/placeholder.png'; 

const ArtCard = ({ title, artist, imageUrl }) => {
  // ✨ NEW FEATURE: State for favorite button
  const [isLiked, setIsLiked] = useState(false);

  const toggleLike = (e) => {
    e.preventDefault(); // Prevent link navigation if card is wrapped in <a>
    setIsLiked(!isLiked);
  };

  return (
    <div className="art-card">
      <div className="art-card-image-wrapper">
        <img src={imageUrl || placeholderImg} alt={title} />
      </div>
      <div className="art-card-info">
        {/* ✨ NEW FEATURE: Favorite button */}
        <div 
          className={`art-card-favorite ${isLiked ? 'liked' : ''}`}
          onClick={toggleLike}
          title="Add to favorites"
        >
          ❤
        </div>
        <h3>{title}</h3>
        <p>by {artist}</p>
      </div>
    </div>
  );
};

export default ArtCard; 