import React from 'react';
import { NavLink, Link } from 'react-router-dom'; // Import Link

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="nav-logo">
        <NavLink to="/">ArtConnect</NavLink>
      </div>
      <nav className="nav-links">
        <NavLink to="/" className={({ isActive }) => (isActive ? 'active' : '')}>Home</NavLink>
        <NavLink to="/artist-dashboard" className={({ isActive }) => (isActive ? 'active' : '')}>For Artists</NavLink>
        <NavLink to="/visitor-dashboard" className={({ isActive }) => (isActive ? 'active' : '')}>Gallery</NavLink>
        <NavLink to="/curator-dashboard" className={({ isActive }) => (isActive ? 'active' : '')}>Curators</NavLink>
        <div className="nav-auth">
            {/* ✨ CHANGE: Converted button to a Link component */}
            <Link to="/login" className="btn btn-secondary">Login</Link>
            <button className="btn btn-primary">Sign Up</button>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;