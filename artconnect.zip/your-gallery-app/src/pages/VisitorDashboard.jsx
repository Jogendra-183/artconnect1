import React from 'react';
import ArtCard from '../components/ArtCard';

const galleryArtworks = [
    { id: 1, title: 'Echoes of Silence', artist: 'John Doe', imageUrl: 'https://picsum.photos/seed/g/400/300' },
    { id: 2, title: 'Digital Bloom', artist: 'Jane Smith', imageUrl: 'https://picsum.photos/seed/h/400/300' },
    { id: 3, title: 'Future Past', artist: 'Alex Ray', imageUrl: 'https://picsum.photos/seed/i/400/300' },
    { id: 4, title: 'Neon Dreams', artist: 'Mia Wallace', imageUrl: 'https://picsum.photos/seed/j/400/300' },
    { id: 5, title: 'Concrete Jungle', artist: 'Leo Kim', imageUrl: 'https://picsum.photos/seed/k/400/300' },
    { id: 6, title: 'Solar Flare', artist: 'Sara Tonin', imageUrl: 'https://picsum.photos/seed/l/400/300' },
];

const VisitorDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1>Explore the Gallery</h1>
        <p>Discover your next favorite piece from our curated collection.</p>
      </div>
      
      {/* ✨ NEW FEATURE: Search and Filter bar */}
      <div className="filters-and-search">
        <div className="search-bar form-group">
            <label htmlFor="search">Search Artworks</label>
            <input type="text" id="search" placeholder="Search by title, artist, or keyword..." />
        </div>
        <div className="filter-group form-group">
            <label htmlFor="style">Style</label>
            <select id="style">
                <option>All Styles</option>
                <option>Abstract</option>
                <option>Modern</option>
                <option>Impressionism</option>
            </select>
        </div>
         <div className="filter-group form-group">
            <label htmlFor="price">Price Range</label>
            <select id="price">
                <option>All Prices</option>
                <option>Under $500</option>
                <option>$500 - $2,000</option>
                <option>Above $2,000</option>
            </select>
        </div>
      </div>
      
      <div className="grid-container">
        {galleryArtworks.map(art => (
          <ArtCard
            key={art.id}
            title={art.title}
            artist={art.artist}
            imageUrl={art.imageUrl}
          />
        ))}
      </div>
    </div>
  );
};

export default VisitorDashboard;