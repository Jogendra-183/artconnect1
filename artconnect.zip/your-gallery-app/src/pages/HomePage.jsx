import React from 'react';
import ArtCard from '../components/ArtCard';
import { Link } from 'react-router-dom';

const featuredArtworks = [
  { id: 1, title: 'Sonata of Colors', artist: 'Elara Vance', imageUrl: 'https://picsum.photos/seed/p1/600/800' },
  { id: 2, title: 'Metropolitan Haze', artist: 'Julian Cross', imageUrl: 'https://picsum.photos/seed/p2/600/800' },
  { id: 3, title: 'Whispers of Terra', artist: 'Aria Chen', imageUrl: 'https://picsum.photos/seed/p3/600/800' },
];

const HomePage = () => {
  return (
    <div>
      <section className="hero-section">
        <h1>Where Art & Connection Flourish</h1>
        <p>The premier platform for discovering exceptional artists and curating world-class digital exhibitions.</p>
        <Link to="/visitor-dashboard" className="btn btn-primary">Explore The Gallery</Link>
      </section>
      
      <h2>Featured Collection</h2>
      <div className="grid-container">
        {featuredArtworks.map(art => (
          <ArtCard
            key={art.id}
            title={art.title}
            artist={art.artist}
            imageUrl={art.imageUrl}
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;