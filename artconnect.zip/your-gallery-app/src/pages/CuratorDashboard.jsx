import React from 'react';

const exhibitions = [
  { id: 1, title: 'A Journey Through Light', status: 'Published' },
  { id: 2, title: 'Cultural Crossroads', status: 'Draft' },
];

const CuratorDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1>Curator Dashboard</h1>
        <p>Craft unique exhibitions and tell compelling cultural stories.</p>
      </div>

      <div className="card">
        <h2>Create New Exhibition</h2>
        <form>
          <div className="form-group">
            <label htmlFor="exhibitionTitle">Exhibition Title</label>
            <input type="text" id="exhibitionTitle" />
          </div>
          {/* ✨ NEW FEATURE: Date Pickers */}
          <div style={{display: 'flex', gap: '1rem'}}>
              <div className="form-group" style={{flex: 1}}>
                  <label htmlFor="startDate">Start Date</label>
                  <input type="date" id="startDate" />
              </div>
              <div className="form-group" style={{flex: 1}}>
                  <label htmlFor="endDate">End Date</label>
                  <input type="date" id="endDate" />
              </div>
          </div>
          <button type="submit" className="btn btn-primary">Create Exhibition</button>
        </form>
      </div>
      
      {/* ✨ NEW FEATURE: Enhanced Exhibition List */}
      <div className="card">
        <h2>Managed Exhibitions</h2>
        {exhibitions.map(ex => (
            <div className="managed-exhibition" key={ex.id}>
                <div className="artwork-details">
                    <h4>{ex.title}</h4>
                    <span className={`status-badge ${ex.status === 'Published' ? 'status-published' : 'status-draft'}`}>
                        {ex.status}
                    </span>
                </div>
                <div className="artwork-actions">
                    <button className="btn btn-secondary">Edit</button>
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default CuratorDashboard;