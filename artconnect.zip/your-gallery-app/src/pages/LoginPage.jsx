import React from 'react';
import { Link } from 'react-router-dom';

// You can replace this with an actual image in your assets folder
const visualImageUrl = 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1945&auto=format&fit=crop';

const LoginPage = () => {
  return (
    <div className="login-container">
      <div className="login-panel">
        
        {/* Left Side: Visual */}
        <div className="login-visual" style={{ backgroundImage: `url(${visualImageUrl})` }}>
          <div className="login-visual-overlay">
            <h2>ArtConnect</h2>
            <p>"Art is not what you see, but what you make others see." - Edgar Degas</p>
          </div>
        </div>

        {/* Right Side: Form */}
        <div className="login-form-container">
          <div className="login-form-header">
            <h1>Sign In</h1>
            <p>Welcome back. Please enter your details.</p>
          </div>

          <form className="login-form">
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input type="email" id="email" placeholder="you@example.com" />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" id="password" placeholder="••••••••" />
            </div>
            <div className="form-options">
              <div className="remember-me">
                <input type="checkbox" id="remember" />
                <label htmlFor="remember">Remember me</label>
              </div>
              <Link to="/forgot-password" className="forgot-password-link">Forgot password?</Link>
            </div>
            <button type="submit" className="btn btn-primary login-btn">Sign In</button>
          </form>

          <div className="signup-prompt">
            <p>Don't have an account? <Link to="/signup" className="signup-link">Sign up</Link></p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default LoginPage;