import React from 'react';

const myArtworks = [
  { id: 1, title: 'Crimson Tide', status: 'For Sale', imageUrl: 'https://picsum.photos/seed/e/400/300' },
  { id: 2, title: 'Metropolis Glow', status: 'Sold', imageUrl: 'https://picsum.photos/seed/f/400/300' },
  { id: 3, title: 'New Horizon', status: 'For Sale', imageUrl: 'https://picsum.photos/seed/m/400/300' },
];

const ArtistDashboard = () => {
  return (
    <div>
      <div className="page-header">
        <h1>Artist Dashboard</h1>
        <p>Manage your portfolio, track your performance, and connect with collectors.</p>
      </div>

      {/* ✨ NEW FEATURE: Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
            <h3>$12,450</h3>
            <p>Total Revenue</p>
        </div>
        <div className="stat-card">
            <h3>15</h3>
            <p>Artworks Sold</p>
        </div>
        <div className="stat-card">
            <h3>2,890</h3>
            <p>Followers</p>
        </div>
      </div>
      
      {/* ✨ NEW FEATURE: Enhanced Artwork Management List */}
      <div className="card">
        <h2>Your Collection</h2>
        {myArtworks.map(art => (
            <div className="managed-artwork" key={art.id}>
                <img src={art.imageUrl} alt={art.title} />
                <div className="artwork-details">
                    <h4>{art.title}</h4>
                    <span className={`status-badge ${art.status === 'For Sale' ? 'status-for-sale' : 'status-sold'}`}>
                        {art.status}
                    </span>
                </div>
                <div className="artwork-actions">
                    <button className="btn btn-secondary">Edit</button>
                    <button className="btn btn-secondary">Delete</button>
                </div>
            </div>
        ))}
      </div>

      <div className="card">
        <h2>Upload New Artwork</h2>
        {/* Form remains the same */}
        <form>
          <div className="form-group">
            <label htmlFor="title">Artwork Title</label>
            <input type="text" id="title" placeholder="e.g., Starry Night 2.0" />
          </div>
          <div className="form-group">
            <label htmlFor="artworkFile">Upload File</label>
            <input type="file" id="artworkFile" />
          </div>
          <button type="submit" className="btn btn-primary">Upload Artwork</button>
        </form>
      </div>
    </div>
  );
};

export default ArtistDashboard;